# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

import json
import wtforms
from flask import render_template, request, redirect, url_for, flash, current_app, send_file, abort
from io import BytesIO
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from jinja2 import TemplateNotFound

from apps.home import blueprint
from apps import db
from apps.models import get_jobs, count_jobs
from apps.tasks import *
from apps.authentication.models import User as User

from flask_wtf import FlaskForm



# Định nghĩa các kiểu file được phép
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif'}

# Kiểm tra xem file có hợp lệ không (dựa vào phần mở rộng file)
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
# ------------------------------
@blueprint.route('/')
@blueprint.route('/index')
def index():
    page = int(request.args.get('page', 1))  # Nếu không có 'page' thì mặc định là 1
    per_page = 9  # Số lượng jobs mỗi trang
    offset = (page - 1) * per_page

    jobs = get_jobs(offset, per_page)
    total = count_jobs()
    total_pages = (total + per_page - 1) // per_page

    return render_template(
        'pages/index.html',
        segment='index',
        jobs=jobs,
        page=page,
        total_pages=total_pages
    )


# ------------------------------
# Các trang tĩnh giữ nguyên
# ------------------------------
@blueprint.route('/icon_feather')
def icon_feather():
    return render_template('pages/icon-feather.html', segment='icon_feather')

@blueprint.route('/color')
def color():
    return render_template('pages/color.html', segment='color')

@blueprint.route('/sample_page')
def sample_page():
    return render_template('pages/sample-page.html', segment='sample_page')

@blueprint.route('/typography')
def typography():
    return render_template('pages/typography.html', segment='typography')

# ------------------------------
# Trang Profile (giữ nguyên)
# ------------------------------
@blueprint.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    # Tạo form để chỉnh sửa thông tin
    class ProfileForm(FlaskForm): pass

    # Danh sách các trường không cho phép sửa (readonly_fields)
    readonly_fields = ['password_hash', 'role']  # Thêm các trường bạn muốn khóa chỉnh sửa

    # Tạo các trường form từ model User
    for column in User.__table__.columns:
        if column.name == "id_user":  # Không cho phép sửa id_user
            continue
        field_name = column.name
        if field_name in readonly_fields:
            continue  # Không tạo form field cho các trường readonly
        field = getField(column)
        setattr(ProfileForm, field_name, field)

    form = ProfileForm(obj=current_user)

    if form.validate_on_submit():
        # Lưu các trường không phải readonly
        for field_name, field_value in form.data.items():
            if field_name not in readonly_fields:
                setattr(current_user, field_name, field_value)

        db.session.commit()
        flash('Thông tin đã được cập nhật thành công!', 'success')
        return redirect(url_for('home_blueprint.profile'))

    context = {
        'segment': 'profile',
        'form': form,
        'readonly_fields': readonly_fields
    }
    return render_template('pages/profile.html', **context)


# ------------------------------
# Helper: Get WTForms field from SQLAlchemy type
# ------------------------------
def getField(column):
    if isinstance(column.type, db.Text):
        return wtforms.TextAreaField(column.name.title())
    if isinstance(column.type, db.String):
        return wtforms.StringField(column.name.title())
    if isinstance(column.type, db.Boolean):
        return wtforms.BooleanField(column.name.title())
    if isinstance(column.type, db.Integer):
        return wtforms.IntegerField(column.name.title())
    if isinstance(column.type, db.Float):
        return wtforms.DecimalField(column.name.title())
    if isinstance(column.type, db.LargeBinary):
        return wtforms.HiddenField(column.name.title())
    return wtforms.StringField(column.name.title())


# ------------------------------
# Custom template filter
# ------------------------------
@blueprint.app_template_filter("replace_value")
def replace_value(value, arg):
    return value.replace(arg, " ").title()


# ------------------------------
# Trang lỗi & xử lý lỗi
# ------------------------------
@blueprint.route('/error-403')
def error_403():
    return render_template('error/403.html'), 403

@blueprint.errorhandler(403)
def not_found_error(error):
    return redirect(url_for('error-403'))

@blueprint.route('/error-404')
def error_404():
    return render_template('error/404.html'), 404

@blueprint.errorhandler(404)
def not_found_error(error):
    return redirect(url_for('error-404'))

@blueprint.route('/error-500')
def error_500():
    return render_template('error/500.html'), 500

@blueprint.errorhandler(500)
def not_found_error(error):
    return redirect(url_for('error-500'))


# ------------------------------
# Celery test route
# ------------------------------
@blueprint.route('/tasks-test')
def tasks_test():
    input_dict = { "data1": "04", "data2": "99" }
    input_json = json.dumps(input_dict)
    task = celery_test.delay(input_json)
    return f"TASK_ID: {task.id}, output: { task.get() }"


@blueprint.route('/update_profile', methods=['GET', 'POST'])
@login_required
def update_profile():
    if request.method == 'POST':
        # Lấy các file từ form
        cv_file = request.files.get('cv_file')
        avatar_file = request.files.get('avatar_file')

        # Lưu file CV nếu có
        if cv_file and allowed_file(cv_file.filename):
            filename = secure_filename(cv_file.filename)
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)  # Tạo đường dẫn file
            cv_file.save(file_path)  # Lưu file vào thư mục
            current_user.cv_file = file_path  # Lưu đường dẫn file vào cơ sở dữ liệu

        # Lưu file Avatar nếu có
        if avatar_file and allowed_file(avatar_file.filename):
            filename = secure_filename(avatar_file.filename)
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)  # Tạo đường dẫn file
            avatar_file.save(file_path)  # Lưu file vào thư mục
            current_user.avatar_file = file_path  # Lưu đường dẫn file vào cơ sở dữ liệu

        db.session.commit()
        flash('Your profile has been updated!', 'success')
        return redirect(url_for('profile'))

    return render_template('update_profile.html')
@blueprint.route('/view_avatar')
@login_required
def view_avatar():
    if current_user.avatar_file:
        avatar_file_path = current_user.avatar_file
        try:
            return send_file(avatar_file_path, mimetype='image/jpeg')
        except Exception as e:
            abort(404, description="Avatar not found.")
    else:
        return "No avatar uploaded.", 404

# Route để tải xuống CV (PDF)
@blueprint.route('/view_cv')
@login_required
def view_cv():
    if current_user.cv_file:
        try:
            return send_file(current_user.cv_file, as_attachment=True, attachment_filename="cv_file.pdf", mimetype='application/pdf')
        except Exception as e:
            flash('Error while retrieving your CV.', 'danger')
            return redirect(url_for('authentication_blueprint.profile'))
    else:
        flash('No CV uploaded.', 'warning')
        return redirect(url_for('authentication_blueprint.profile'))